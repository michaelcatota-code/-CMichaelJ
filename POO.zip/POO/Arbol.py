# -*- coding: utf-8 -*-
"""
Created on Mon Nov  3 23:01:48 2025

@author: Exxa Strean Music
"""

class Arbol:
    def __init__(self,Especie,Altura,Edad,Tipo_de_hoja,Ubicacion):
        self.Especie=Especie
        self.Altura=Altura
        self.Edad=Edad
        self.Tipo_de_hoja=Tipo_de_hoja
        self.Ubicacion=Ubicacion
    def crecer():
        pass
    def fotosinterizar():
        pass
    def perder_hoja():
        pass
    def cumplir_anio():
        pass
    def mostrar_info():
        pass
arbol1=Arbol("Arbol de tomate","4 metros", "5 años ", "Hojas perrenes ", "Ecuador ")
print(arbol1.Especie)
print(arbol1.Altura)
