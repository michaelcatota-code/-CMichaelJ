# -*- coding: utf-8 -*-
"""
Created on Tue Nov  4 18:26:56 2025

@author: Exxa Strean Music
"""

class Led:
    def __init__(self,color,potencia):
        self.color=color
        self.potencia=potencia
        self.encendido=False
        
    def enecender():
        pass
    def apagar():
        pass
    def cambiar_estado():
        pass

class led_boton():
    def __init__(self,color,material,tamanio,conectado_a):
        self.color=color
        self.material=material
        self.tamanio=tamanio
        self.conectado_a=conectado_a
    def presionar():
        pass
    def soltar():
        pass
    def estado():
        pass
led1=Led("Rojo", "5V")
boton1=led_boton("negro", "plastico", "pequeño", "Conectado a led1")
print(led1.color)
print(boton1.conectado_a)