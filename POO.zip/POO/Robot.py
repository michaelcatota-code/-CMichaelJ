# -*- coding: utf-8 -*-
"""
Editor de Spyder

Este es un archivo temporal.
"""

class robot:
    def __init__(self, Unidad_control,Fuente_energia,Estructura_mecanica,Sensores):
        self.Unidad_control=Unidad_control
        self.Fuente_energia=Fuente_energia
        self.Estructura_mecanica=Estructura_mecanica
        self.Sensores=Sensores
    def Accion_y_movimiento():
        pass
    def Adaptabilidad():
        pass
    def Control(self):
        pass
    def Comunicacion():
        pass

Robot1=robot("Arduino","Bateria recargable","Metalica ","Sonido")
print(Robot1.Estructura_mecanica)
print(Robot1.Unidad_control)

