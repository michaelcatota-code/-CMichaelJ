# -*- coding: utf-8 -*-
"""
Created on Mon Nov  3 20:59:01 2025

@author: Exxa Strean Music
"""

class Red_social:
    def __init__(self,nombre,tipo_de_contenido,pais_de_origen,usuarios_activados,version):
        self.nombre=nombre
        self.tipo_de_contenido=tipo_de_contenido
        self.pais_de_origen=pais_de_origen
        self.usuarios_activados=usuarios_activados
        self.version=version
    def resgitrar_usuario():
        pass
    def subir_contenido():
        pass
    def reaccionar_publicaciones():
        pass
    def seguir_usuario():
        pass
    def actualizar_version():
        pass
Usuario1=Red_social("Instagram", "Historias", "Estados Unidos ", "2000000", "405.0.0.0.71")
print(Usuario1.nombre)
print(Usuario1.usuarios_activados)