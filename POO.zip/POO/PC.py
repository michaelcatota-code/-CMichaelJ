# -*- coding: utf-8 -*-
"""
Created on Mon Nov  3 22:18:38 2025

@author: Exxa Strean Music
"""

class PC:
    def __init__(self,Procesador,Memoria_Ram,Almacenamiento,Tarjeta_Grafica,Sistema_operativo):
        self.Procesador=Procesador
        self.Memoria_Ram=Memoria_Ram
        self.Almacenamiento=Almacenamiento
        self.Tarjeta_Grafica=Tarjeta_Grafica
        self.Sistema_operativo=Sistema_operativo
    def ejecutar_programa():
        pass
    def guardar_archivos():
        pass
    def cargar_datos():
        pass
    def procesar_imagnes():
        pass
    def iniciar():
        pass
PC1=PC("Intel Core i5", "16 Gb", "1 TB", "RX 9060 XT", "Windows")
print(PC1.Procesador)
print(PC1.Sistema_operativo)