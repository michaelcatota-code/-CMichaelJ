# -*- coding: utf-8 -*-
"""
Created on Mon Nov  3 18:18:13 2025

@author: Exxa Strean Music
"""

class telefono:
    def __init__(self,marca,modelo,sistema,almacenamiento,bateria):
        self.marca=marca
        self.modelo=modelo
        self.sistema=sistema
        self.almacenamiento=almacenamiento
        self.bateria=bateria
    def llamar():
        pass
    def enviar_mensaje():
        pass
    def encender():
        pass
    def tomar_foto():
        pass
    def cargar(self):
        pass
telefono1=telefono("Samsung","Galaxi 12","Android", "68gb", "500mAh")
print(telefono1.modelo)
print(telefono1.bateria)

telefono2=telefono("Apple", "Ifhone 12", "IOS", "128Gb", "4500mAh")
print(telefono2.sistema)