# -*- coding: utf-8 -*-
"""
Created on Mon Nov  3 22:45:35 2025

@author: Exxa Strean Music
"""

class Navegador:
    def __init__(self,Motor_de_busqueda,Historial,Marcadores,Pestañas):
        self.Motor_de_busqueda=Motor_de_busqueda
        self.Historial=Historial
        self.Marcadores=Marcadores
        self.Pestañas=Pestañas
    def buscar():
        pass
    def mostral_historial():
        pass
    def guardar_pagina():
        pass
    def abrir_nueva_pestaña():
        pass
navegador1=Navegador("Google", "Historial vacio","Ninguno", "5")
print(navegador1.Motor_de_busqueda)
print(navegador1.Historial)