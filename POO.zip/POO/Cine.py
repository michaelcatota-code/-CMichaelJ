# -*- coding: utf-8 -*-
"""
Created on Mon Nov  3 19:18:46 2025

@author: Exxa Strean Music
"""

class cine:
    def __init__(self,Titulo,Genero,Director,Duracion,Año):
        self.Titulo=Titulo
        self.Genero=Genero
        self.Director=Director
        self.Duracion=Duracion
        self.Año=Año
    def reproducir():
        pass
    def pausar():
        pass
    def calificar():
        pass
    def recomendar():
        pass
    def guardar():
        pass
pelicula1=cine("Avenger endgame","Accion", "Kevin Feige", "207 minutos ","2019")
print(pelicula1.Director)
print(pelicula1.Genero)