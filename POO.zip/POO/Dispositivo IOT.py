# -*- coding: utf-8 -*-
"""
Created on Mon Nov  3 20:47:18 2025

@author: Exxa Strean Music
"""

class Dispositivo_IOT:
    def __init__(self,Sensor,Microcontrolador,Conectividad,Fuente_de_energia):
        self.Sensor=Sensor
        self.Microcontrolador=Microcontrolador
        self.Conectividad=Conectividad
        self.Fuente_de_energia=Fuente_de_energia
    def controlar():
        pass
    def obtencion_de_datos():
        pass
    def ubicacion():
        pass
    def estado():
        pass
dispositivo1=Dispositivo_IOT("sensor de humudad", "arduino", "Bluetooth", "bateria recargable")
print(dispositivo1.Microcontrolador)
print(dispositivo1.Conectividad)
