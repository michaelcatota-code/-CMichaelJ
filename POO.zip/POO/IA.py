# -*- coding: utf-8 -*-
"""
Created on Mon Nov  3 19:39:25 2025

@author: Exxa Strean Music
"""

class IA:
    def __init__(self,Nombre,Tipo,Lenguaje,Capacidad,Nivel):
        self.Nombre=Nombre
        self.Tipo=Tipo
        self.Lenguaje=Lenguaje
        self.Capacidad=Capacidad
        self.Nivel=Nivel
    def aprender():
        pass
    def analizar():
        pass
    def procesar():
        pass
    def responder():
        pass
    def optimizar():
        pass

inteligencia1=IA("Alexa","IA debil ", "Python", "Reconocer comando de voz ", "IA Intermedio")
print(inteligencia1.Lenguaje)
print(inteligencia1.Capacidad)
