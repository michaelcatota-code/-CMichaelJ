# -*- coding: utf-8 -*-
"""
Created on Tue Nov 18 21:48:37 2025

@author: Exxa Strean Music
"""

from vista import VistaRobot
from controlador import ControladorRobot

vista = VistaRobot()
controlador = ControladorRobot(vista)

controlador.iniciar()
