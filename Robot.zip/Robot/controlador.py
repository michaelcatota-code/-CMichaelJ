# -*- coding: utf-8 -*-
"""
Created on Tue Nov 18 21:42:29 2025

@author: Exxa Strean Music
"""

from modelo import RobotExplorador, RobotIndustrial

class ControladorRobot:
    def __init__(self, vista):
        self.vista = vista
        self.robots = {
            "1": RobotExplorador(),
            "2": RobotIndustrial()
        }

    def elegir_robot(self):
        self.vista.mostrar("\nSeleccione un robot:")
        self.vista.mostrar("1 - RobotExplorador")
        self.vista.mostrar("2 - RobotIndustrial")
        self.vista.mostrar("3 Salir del programa")

        opcion = self.vista.pedir("Ingrese opción: ")
        return self.robots.get(opcion)

    def menu_robot(self, robot):
        while True:
            self.vista.mostrar(f"\nControlando: {robot.nombre}")
            self.vista.mostrar("1 - Encender")
            self.vista.mostrar("2 - Apagar")
            self.vista.mostrar("3 - Mover")
            self.vista.mostrar("4 - Salir")

            opcion = self.vista.pedir("Ingrese opción: ")

            if opcion == "1":
                robot.encender()
                self.vista.mostrar("Encendido.")

            elif opcion == "2":
                robot.apagar()
                self.vista.mostrar("Apagado.")

            elif opcion == "3":
                direccion = self.vista.pedir("Dirección: ")
                robot.mover(direccion)
                self.vista.mostrar("Movimiento registrado.")

            elif opcion == "4":
                break

            else:
                self.vista.mostrar("Opción inválida.")

    def iniciar(self):
        while True:
            robot = self.elegir_robot()
            if robot:
                self.menu_robot(robot)
            else:
                self.vista.mostrar("Opción no válida.")

