# -*- coding: utf-8 -*-
"""
Created on Tue Nov 18 21:42:16 2025

@author: Exxa Strean Music
"""

class VistaRobot:
    def mostrar(self, mensaje):
        print(mensaje)

    def pedir(self, mensaje):
        return input(mensaje)
