# -*- coding: utf-8 -*-
"""
Created on Tue Nov 18 21:39:35 2025

@author: Exxa Strean Music
"""

from datetime import datetime

class Robot:
    def __init__(self, nombre):
        self.nombre = nombre
        self.encendido = False

    def registrar(self, mensaje):
        with open("log.txt", "a") as archivo:
            fecha = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            archivo.write(f"[{fecha}] {mensaje}\n")

    def encender(self):
        self.encendido = True
        self.registrar(f"{self.nombre} encendido")

    def apagar(self):
        self.encendido = False
        self.registrar(f"{self.nombre} apagado")

    def mover(self, direccion):
        if self.encendido:
            self.registrar(f"{self.nombre} moviendo hacia {direccion}")
        else:
            self.registrar(f"{self.nombre} no puede moverse porque está apagado")


class RobotExplorador(Robot):
    def __init__(self):
        super().__init__("RobotExplorador")


class RobotIndustrial(Robot):
    def __init__(self):
        super().__init__("RobotIndustrial")
